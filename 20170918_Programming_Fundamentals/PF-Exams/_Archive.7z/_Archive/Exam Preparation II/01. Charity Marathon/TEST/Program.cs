﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TEST
{
    class Program
    {
        static void Main(string[] args)
        {
            var input = Console.ReadLine().Select(x => (int)(x)).Where(x => x >= 65 && x <= 90 || x >= 97 && x <= 122).ToArray().Sum();
            //Console.WriteLine(String.Join(" ", input));
            Console.WriteLine(input);
        }
    }
}
    